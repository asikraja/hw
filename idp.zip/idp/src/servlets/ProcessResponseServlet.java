
package servlets;

import org.apache.commons.codec.binary.Base64;
import org.jdom.Document;



import util.SamlException;
import util.Util;
import util.XmlDigitalSigner;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.interfaces.DSAPrivateKey;
import java.security.interfaces.DSAPublicKey;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

public class ProcessResponseServlet extends HttpServlet {

	
	private static final long serialVersionUID = 1L;
	private final String samlResponseTemplateFile = "SamlResponseTemplate.xml";
	private static final String domainName = "";

	private String login(String username, String password) {
		//Local Authentication
		return "TESTADVISERID";
	}

	private String decodeAuthnRequestXML(String encodedRequestXmlString) throws SamlException {
		try {
			
			Base64 base64Decoder = new Base64();
			byte[] xmlBytes = encodedRequestXmlString.getBytes("UTF-8");
			byte[] base64DecodedByteArray = base64Decoder.decode(xmlBytes);

			try {

				Inflater inflater = new Inflater(true);
				inflater.setInput(base64DecodedByteArray);
				byte[] xmlMessageBytes = new byte[5000];
				int resultLength = inflater.inflate(xmlMessageBytes);

				if (!inflater.finished()) {
					throw new RuntimeException("didn't allocate enough space to hold " + "decompressed data");
				}

				inflater.end();
				return new String(xmlMessageBytes, 0, resultLength, "UTF-8");

			} catch (DataFormatException e) {

				ByteArrayInputStream bais = new ByteArrayInputStream(base64DecodedByteArray);
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				InflaterInputStream iis = new InflaterInputStream(bais);
				byte[] buf = new byte[1024];
				int count = iis.read(buf);
				while (count != -1) {
					baos.write(buf, 0, count);
					count = iis.read(buf);
				}
				iis.close();
				return new String(baos.toByteArray());
			}

		} catch (UnsupportedEncodingException e) {
			throw new SamlException("Error decoding AuthnRequest: " + "Check decoding scheme - " + e.getMessage());
		} catch (IOException e) {
			throw new SamlException("Error decoding AuthnRequest: " + "Check decoding scheme - " + e.getMessage());
		}
	}

	private String[] getRequestAttributes(String xmlString) throws SamlException {
		Document doc = Util.createJdomDoc(xmlString);
		if (doc != null) {
			String[] samlRequestAttributes = new String[3];
			samlRequestAttributes[0] = doc.getRootElement().getAttributeValue("IssueInstant");
			samlRequestAttributes[1] = doc.getRootElement().getAttributeValue("ProviderName");
			samlRequestAttributes[2] = doc.getRootElement().getAttributeValue("AssertionConsumerServiceURL");
			return samlRequestAttributes;
		} else {
			throw new SamlException("Error parsing AuthnRequest XML: Null document");
		}
	}

	private String createSamlResponse(String authenticatedUser, String notBefore, String notOnOrAfter)throws SamlException {
		
		String filepath = getServletContext().getRealPath("templates/" + samlResponseTemplateFile);
		String samlResponse = Util.readFileContents(filepath);
		

		samlResponse = samlResponse.replace("USERNAME_STRING", authenticatedUser);
		samlResponse = samlResponse.replace("RESPONSE_ID", Util.createID());
		samlResponse = samlResponse.replace("ISSUE_INSTANT", Util.getDateAndTime());
		samlResponse = samlResponse.replace("AUTHN_INSTANT", Util.getDateAndTime());
		samlResponse = samlResponse.replace("NOT_BEFORE", notBefore);
		samlResponse = samlResponse.replace("NOT_ON_OR_AFTER", notOnOrAfter);
		samlResponse = samlResponse.replace("ASSERTION_ID", Util.createID());


		return samlResponse;

	}

	private String signResponse(String response, DSAPublicKey publicKey, DSAPrivateKey privateKey)	throws SamlException {
		return (XmlDigitalSigner.signXML(response, publicKey, privateKey));
	}

	private boolean validSamlDateFormat(String samlDate) {
		if (samlDate == null) {
			return false;
		}
		int indexT = samlDate.indexOf("T");
		int indexZ = samlDate.indexOf("Z");
		if (indexT != 10 || indexZ != 19) {
			return false;
		}
		String dateString = samlDate.substring(0, indexT);
		String timeString = samlDate.substring(indexT + 1, indexZ);
		SimpleDateFormat dayFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
		ParsePosition pos = new ParsePosition(0);
		Date parsedDate = dayFormat.parse(dateString, pos);
		pos = new ParsePosition(0);
		Date parsedTime = timeFormat.parse(timeString, pos);
		if (parsedDate == null || parsedTime == null) {
			return false;
		}
		return true;
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String SAMLRequest = request.getParameter("SAMLRequest");
		String relayStateURL = request.getParameter("RelayState");
		
		if (SAMLRequest != null) {
			try {
				String requestXmlString = decodeAuthnRequestXML(SAMLRequest);
				String[] samlRequestAttributes = getRequestAttributes(requestXmlString);
				String issueInstant = samlRequestAttributes[0];
				String providerName = samlRequestAttributes[1];
				String acsURL = samlRequestAttributes[2];
				request.setAttribute("issueInstant", issueInstant);
				request.setAttribute("providerName", providerName);
				request.setAttribute("acsURL", acsURL);
				request.setAttribute("relayStateURL", relayStateURL);
			} catch (SamlException e) {
				request.setAttribute("error", e.getMessage());
			}
		}

		String returnPage = "./identity_provider.jsp";
		request.getRequestDispatcher(returnPage).include(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String samlAction = request.getParameter("samlAction");
		String relayStateURL = request.getParameter("RelayState");
		String SAMLRequest = request.getParameter("SAMLRequest");
		String returnPage = request.getParameter("returnPage");
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");


		boolean continueLogin = true;

		if (SAMLRequest == null || SAMLRequest.equals("null")) {
			
			continueLogin = false;
			request.setAttribute("error", "ERROR: Unspecified SAML parameters.");
			
		} else if (samlAction == null) {
			
			continueLogin = false;
			request.setAttribute("error", "ERROR: Invalid SAML action.");
			
		} else if (returnPage != null) {
			try {
				// Parse the SAML request and extract the ACS URL and provider name
				// Extract the Assertion Consumer Service URL from AuthnRequest
				
				String requestXmlString = decodeAuthnRequestXML(SAMLRequest);
				String[] samlRequestAttributes = getRequestAttributes(requestXmlString);
				String issueInstant = samlRequestAttributes[0];
				String providerName = samlRequestAttributes[1];
				String acsURL = samlRequestAttributes[2];

				System.out.println("issueInstant------->" + issueInstant+",providerName------->" + providerName+",acsURL------->" + acsURL);

				username = login(username, password);

				// The following lines of code set variables used in the UI.
				request.setAttribute("issueInstant", issueInstant);
				request.setAttribute("providerName", providerName);
				request.setAttribute("acsURL", acsURL);
				request.setAttribute("domainName", domainName);
				request.setAttribute("username", username);
				request.setAttribute("relayStateURL", relayStateURL);

				if (username == null) {
					request.setAttribute("error", "Login Failed: Invalid user.");
				} else {
					// Acquire public and private DSA keys

					/*
					 * keys that digitally sign SAML responses
					 */

					// First, verify that the NotBefore and NotOnOrAfter values are valid
					String notBefore = "2018-08-15T00:00:01Z";
					String notOnOrAfter = "2019-12-31T00:51:02Z";
					request.setAttribute("notBefore", notBefore);
					request.setAttribute("notOnOrAfter", notOnOrAfter);

					if (!validSamlDateFormat(issueInstant)) {
						continueLogin = false;
						request.setAttribute("error", "ERROR: Invalid NotBefore date specified - " + notBefore);
					} else if (!validSamlDateFormat(notOnOrAfter)) {
						continueLogin = false;
						request.setAttribute("notOnOrAfter", "2008-04-17T00:51:02Z");
						request.setAttribute("error", "ERROR: Invalid NotOnOrAfter date specified - " + notOnOrAfter);
					}

					// Sign XML containing user name with specified keys
					if (continueLogin) {
						// Generate SAML response contaning specified user name
						String responseXmlString = createSamlResponse(username, notBefore, notOnOrAfter);
						
						request.setAttribute("SAMLResponse", responseXmlString);
						request.setAttribute("samlResponse",  responseXmlString);
						request.setAttribute("CASEID", "FNA0000000000001");

					}
				}
			} catch (SamlException e) {
				request.setAttribute("error", e.getMessage());
			}
		}
		// Forward SAML response to ACS
		request.getRequestDispatcher(returnPage).include(request, response);
	}
}
