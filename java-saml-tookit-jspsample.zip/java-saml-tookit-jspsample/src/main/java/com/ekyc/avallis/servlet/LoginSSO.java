package com.ekyc.avallis.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.HttpPost;

import com.onelogin.saml2.Auth;
import com.onelogin.saml2.authn.AuthnRequest;
import com.onelogin.saml2.exception.Error;
import com.onelogin.saml2.exception.SettingsException;
import com.onelogin.saml2.servlet.ServletUtils;

/**
 * Servlet implementation class LoginSSO
 */
public class LoginSSO extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginSSO() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("SSO Servlet reached!"+request.getParameter("attrs") );
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession();
		
		Auth auth=null;
		try {
			auth = new Auth(request, response);
			
			//HttpPost post = new HttpPost(request.getParameter("SAMLRequest"));
			//System.out.println("------------>"+post.getURI());
			try {
				auth.processResponse();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SettingsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Error e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		if (!auth.isAuthenticated()) {
			out.println("<div class=\"alert alert-danger\" role=\"alert\">Not authenticated</div>");
		}

		List<String> errors = auth.getErrors();

	    if (!errors.isEmpty()) {
	    	out.println("<p>" + StringUtils.join(errors, ", ") + "</p>");
	    	if (auth.isDebugActive()) {
	    		String errorReason = auth.getLastErrorReason();
	    		if (errorReason != null && !errorReason.isEmpty()) {
	    			out.println("<p>" + auth.getLastErrorReason() + "</p>");
	    		}
	    	}
	    	out.println("<a href=\"dologin.jsp\" class=\"btn btn-primary\">Login</a>");
	    } else {
			Map<String, List<String>> attributes = auth.getAttributes();
			String nameId = auth.getNameId();

			session.setAttribute("attributes", attributes);
			session.setAttribute("nameId", nameId);

			String relayState = request.getParameter("RelayState");

			if (relayState != null && !relayState.isEmpty() && !relayState.equals(ServletUtils.getSelfRoutedURLNoQuery(request)) &&
				!relayState.contains("/dologin.jsp")) { // We don't want to be redirected to login.jsp neither
				response.sendRedirect(request.getParameter("RelayState"));
			} else {
				

				if (attributes.isEmpty()) {
		
					out.println("<div class='alert alert-danger' role='alert'>You don't have any attributes</div>");
									
				}
				else {
	    
					out.println("<table class='table table-striped'>"
							+ "<thead><tr><th>Name11</th><th>Values11</th></tr></thead><tbody>");
	    			
					Collection<String> keys = attributes.keySet();
					for(String name :keys){
						out.println("<tr><td>" + name + "</td><td>");
						List<String> values = attributes.get(name);
						for(String value :values) {
							out.println("<li>" + value + "</li>");
						}
	
						out.println("</td></tr>");
					}
		
					out.println("</tbody></table>");
						
				}
		
				out.println("<a href='attrs.jsp' class='btn btn-primary'>See user data stored at session</a>");
				out.println("<a href='dologout.jsp' class='btn btn-primary'>Logout</a>");
		
			}
		}
	    
//		if (request.getParameter("attrs") == null) {
//			System.out.println("inside null");
//			try {
//				Auth auth = new Auth();
////				System.out.println(auth.getNameId());
//				System.out.println(auth.getSettings().getIdpEntityId());
//				auth.login();
//				
////				AuthnRequest authnRequest = new AuthnRequest(auth.getSettings(), false, false, true);
////				
////				String samlRequest = authnRequest.getEncodedAuthnRequest();
////				System.out.println(samlRequest);
////				Map<String, String> parameters = new HashMap<String, String>();
////				parameters.put("SAMLRequest", samlRequest);
//				
//			} catch (SettingsException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (Error e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} 
//					//.login();
//		}else {
//			System.out.println("inside not null");
//		}
		
	}

}
